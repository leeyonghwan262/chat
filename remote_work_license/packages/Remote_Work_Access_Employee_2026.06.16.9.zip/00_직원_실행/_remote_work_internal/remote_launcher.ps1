param(
    [string]$ProgramKey = "",
    [string]$DisplayName = "",
    [switch]$InstallOnly,
    [switch]$Router,
    [switch]$DryRun,
    [switch]$NoPause
)

$ErrorActionPreference = "Stop"

$ManifestUrl = "https://api.github.com/repos/leeyonghwan262/chat/contents/remote_work_license/update_manifest.json?ref=main"
$FallbackVersion = "2026.06.16.9"
$FallbackZipUrl = "https://raw.githubusercontent.com/leeyonghwan262/chat/main/remote_work_license/packages/Remote_Work_Access_app_2026.06.16.9.zip"
$FallbackSha256 = ""
$CacheRoot = if (-not [string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
    Join-Path $env:LOCALAPPDATA "RemoteWorkAccess"
} else {
    Join-Path $env:TEMP "RemoteWorkAccess"
}
$AppRoot = Join-Path $CacheRoot "app"
$DownloadDir = Join-Path $CacheRoot "downloads"
$PackageZip = Join-Path $DownloadDir "Remote_Work_Access_latest.zip"
$PowerShellExe = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
if (-not (Test-Path -LiteralPath $PowerShellExe)) {
    $PowerShellExe = "powershell.exe"
}
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Write-TroubleshootingHelp {
    Write-Host ""
    Write-Host "If this PC is managed by a company security policy, check these items:" -ForegroundColor Yellow
    Write-Host "- Allow unsigned employee launcher EXE files or sign them with a trusted code-signing certificate."
    Write-Host "- Allow Windows PowerShell to run this launcher script."
    Write-Host "- Allow HTTPS access to api.github.com and raw.githubusercontent.com."
    Write-Host "- Allow writing to %LOCALAPPDATA%\RemoteWorkAccess."
    Write-Host "- On first run, Windows SmartScreen may require More info > Run anyway."
}

function Read-JsonFromUrl {
    param([string]$Url)
    $request = [System.Net.WebRequest]::Create($Url)
    $request.UserAgent = "RemoteWorkLauncher/1.0"
    $request.Timeout = 15000
    $response = $request.GetResponse()
    try {
        $stream = $response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)
        try {
            $raw = $reader.ReadToEnd()
        } finally {
            $reader.Dispose()
        }
    } finally {
        $response.Dispose()
    }
    $raw = $raw.TrimStart([char]0xFEFF)
    $data = $raw | ConvertFrom-Json
    if ($data.encoding -eq "base64" -and $data.content) {
        $decoded = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String(($data.content -replace "`n", ""))).TrimStart([char]0xFEFF)
        return ($decoded | ConvertFrom-Json)
    }
    return $data
}

function Get-InstalledVersion {
    $versionPath = Join-Path $AppRoot "version.json"
    if (-not (Test-Path -LiteralPath $versionPath)) {
        return ""
    }
    try {
        $data = Get-Content -LiteralPath $versionPath -Raw -Encoding UTF8 | ConvertFrom-Json
        return [string]$data.version
    } catch {
        return ""
    }
}

function Get-RemoteManifest {
    try {
        $manifest = Read-JsonFromUrl -Url $ManifestUrl
        $version = [string]$manifest.version
        $zipUrl = [string]$manifest.zip_url
        $sha256 = [string]$manifest.sha256
        if ([string]::IsNullOrWhiteSpace($zipUrl)) {
            $zipUrl = $FallbackZipUrl
        }
        return [pscustomobject]@{ Version = $version; ZipUrl = $zipUrl; Sha256 = $sha256 }
    } catch {
        Write-Warning "Could not read update manifest. Using fallback package URL. $($_.Exception.Message)"
        return [pscustomobject]@{ Version = $FallbackVersion; ZipUrl = $FallbackZipUrl; Sha256 = $FallbackSha256 }
    }
}

function Find-ExtractedRoot {
    param([string]$ExtractDir)
    if (Test-Path -LiteralPath (Join-Path $ExtractDir "license_control")) {
        return $ExtractDir
    }
    $match = Get-ChildItem -LiteralPath $ExtractDir -Directory -Force |
        Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName "license_control") } |
        Select-Object -First 1
    if (-not $match) {
        throw "Downloaded package does not contain license_control."
    }
    return $match.FullName
}

function Test-PackageHash {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [string]$ExpectedSha256
    )
    if ([string]::IsNullOrWhiteSpace($ExpectedSha256)) {
        return
    }
    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
    $expected = $ExpectedSha256.Trim().ToLowerInvariant()
    if ($actual -ne $expected) {
        throw "Downloaded package hash mismatch. Expected $expected but got $actual."
    }
    Write-Host "Downloaded package hash verified."
}

function Get-ParentProcessId {
    try {
        $current = Get-CimInstance Win32_Process -Filter "ProcessId=$PID" -ErrorAction Stop
        return [int]$current.ParentProcessId
    } catch {
        return 0
    }
}

function Get-RemoteWorkProcessMatches {
    $exclude = New-Object System.Collections.Generic.HashSet[int]
    [void]$exclude.Add([int]$PID)
    $parentPid = Get-ParentProcessId
    if ($parentPid -gt 0) {
        [void]$exclude.Add([int]$parentPid)
    }

    $needles = New-Object System.Collections.Generic.List[string]
    foreach ($path in @(
        $AppRoot,
        (Join-Path $AppRoot "blog_auto"),
        (Join-Path $AppRoot "blog_auto\profile"),
        (Join-Path $CacheRoot "user_data\blog_auto")
    )) {
        if (-not [string]::IsNullOrWhiteSpace($path)) {
            $needles.Add($path.ToLowerInvariant())
        }
    }

    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
        Where-Object {
            if ($exclude.Contains([int]$_.ProcessId)) {
                $false
            } elseif ([string]::IsNullOrWhiteSpace($_.CommandLine)) {
                $false
            } else {
                $cmd = $_.CommandLine.ToLowerInvariant()
                $matched = $false
                foreach ($needle in $needles) {
                    if ($cmd.Contains($needle)) {
                        $matched = $true
                        break
                    }
                }
                $matched
            }
        }
}

function Stop-RemoteWorkProcesses {
    $matches = @(Get-RemoteWorkProcessMatches)
    if ($matches.Count -eq 0) {
        return
    }

    Write-Host "Closing running RemoteWorkAccess programs before update..."
    foreach ($item in $matches) {
        Write-Host ("Closing {0} (PID {1})" -f $item.Name, $item.ProcessId)
        try {
            $process = Get-Process -Id $item.ProcessId -ErrorAction Stop
            [void]$process.CloseMainWindow()
        } catch {
        }
    }

    Start-Sleep -Seconds 4

    foreach ($item in @(Get-RemoteWorkProcessMatches)) {
        try {
            Stop-Process -Id $item.ProcessId -Force -ErrorAction Stop
        } catch {
        }
    }

    Start-Sleep -Seconds 1
    $remaining = @(Get-RemoteWorkProcessMatches)
    if ($remaining.Count -gt 0) {
        $names = ($remaining | ForEach-Object { "{0} (PID {1})" -f $_.Name, $_.ProcessId }) -join ", "
        throw "Could not close running RemoteWorkAccess processes: $names. Close all work program windows and try again."
    }
}

function Copy-DirectoryContents {
    param(
        [Parameter(Mandatory=$true)][string]$Source,
        [Parameter(Mandatory=$true)][string]$Destination
    )
    if (-not (Test-Path -LiteralPath $Source)) {
        return
    }
    New-Item -ItemType Directory -Force -Path $Destination | Out-Null
    Get-ChildItem -LiteralPath $Source -Force |
        ForEach-Object {
            $target = Join-Path $Destination $_.Name
            if (-not (Test-Path -LiteralPath $target)) {
                Copy-Item -LiteralPath $_.FullName -Destination $Destination -Recurse -Force
            }
        }
}

function Test-BlogAutoNeedsUserDataMigration {
    $configPath = Join-Path $AppRoot "blog_auto\src\config.py"
    if (-not (Test-Path -LiteralPath $configPath)) {
        return $false
    }
    try {
        $raw = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8
        return ($raw -notmatch "RUNTIME_ROOT" -or $raw -notmatch "BLOG_AUTO_USER_DATA_ROOT")
    } catch {
        return $true
    }
}

function Preserve-BlogAutoUserData {
    $blogAutoRoot = Join-Path $AppRoot "blog_auto"
    if ((-not (Test-Path -LiteralPath $blogAutoRoot)) -or (-not (Test-BlogAutoNeedsUserDataMigration))) {
        return
    }

    $userRoot = Join-Path $CacheRoot "user_data\blog_auto"
    foreach ($name in @("data", "profile", "logs", "output", "temp", "backup")) {
        $source = Join-Path $blogAutoRoot $name
        if (Test-Path -LiteralPath $source) {
            $destination = Join-Path $userRoot $name
            Write-Host ("Preserving Blog Auto user data: {0}" -f $name)
            Copy-DirectoryContents -Source $source -Destination $destination
        }
    }
}

function Remove-PathWithRetry {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [int]$Attempts = 3
    )
    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }

    $lastError = ""
    for ($attempt = 1; $attempt -le $Attempts; $attempt++) {
        try {
            Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
            return
        } catch {
            $lastError = $_.Exception.Message
            if ($attempt -lt $Attempts) {
                Write-Warning ("Install folder is still busy. Retrying cleanup ({0}/{1}). {2}" -f $attempt, $Attempts, $lastError)
                Stop-RemoteWorkProcesses
                Start-Sleep -Seconds ([Math]::Min(5, $attempt * 2))
            }
        }
    }
    throw "Could not replace the installed package because a file is still in use. Close all RemoteWorkAccess, Chrome, and Whale windows, then run the launcher again. Last error: $lastError"
}

function Format-ByteSize {
    param([Int64]$Bytes)
    if ($Bytes -ge 1GB) {
        return ("{0:N1} GB" -f ($Bytes / 1GB))
    }
    if ($Bytes -ge 1MB) {
        return ("{0:N1} MB" -f ($Bytes / 1MB))
    }
    if ($Bytes -ge 1KB) {
        return ("{0:N1} KB" -f ($Bytes / 1KB))
    }
    return ("{0} bytes" -f $Bytes)
}

function Invoke-DownloadFileWithProgress {
    param(
        [Parameter(Mandatory=$true)][string]$Url,
        [Parameter(Mandatory=$true)][string]$OutFile,
        [int]$TimeoutSec = 180
    )
    $request = [System.Net.HttpWebRequest][System.Net.WebRequest]::Create($Url)
    $request.UserAgent = "RemoteWorkLauncher/1.0"
    $request.Timeout = $TimeoutSec * 1000
    $request.ReadWriteTimeout = 30000
    $request.AllowAutoRedirect = $true

    $response = $request.GetResponse()
    try {
        $totalBytes = [Int64]$response.ContentLength
        $inputStream = $response.GetResponseStream()
        $outputStream = [System.IO.File]::Open($OutFile, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
        try {
            $buffer = New-Object byte[] 262144
            $downloadedBytes = [Int64]0
            $lastPercent = -1
            $lastWriteAt = Get-Date
            if ($totalBytes -gt 0) {
                Write-Host ("Download progress: 0% (0 bytes / {0})" -f (Format-ByteSize -Bytes $totalBytes))
            } else {
                Write-Host "Download progress: starting..."
            }
            while ($true) {
                $read = $inputStream.Read($buffer, 0, $buffer.Length)
                if ($read -le 0) {
                    break
                }
                $outputStream.Write($buffer, 0, $read)
                $downloadedBytes += $read
                $now = Get-Date
                if ($totalBytes -gt 0) {
                    $percent = [int][Math]::Floor(($downloadedBytes * 100.0) / $totalBytes)
                    if ($percent -gt 100) {
                        $percent = 100
                    }
                    if (($percent -ge ($lastPercent + 5)) -or (($now - $lastWriteAt).TotalSeconds -ge 5) -or ($percent -eq 100)) {
                        Write-Host ("Download progress: {0}% ({1} / {2})" -f $percent, (Format-ByteSize -Bytes $downloadedBytes), (Format-ByteSize -Bytes $totalBytes))
                        $lastPercent = $percent
                        $lastWriteAt = $now
                    }
                } elseif (($now - $lastWriteAt).TotalSeconds -ge 5) {
                    Write-Host ("Download progress: {0} downloaded" -f (Format-ByteSize -Bytes $downloadedBytes))
                    $lastWriteAt = $now
                }
            }
            if ($totalBytes -gt 0 -and $downloadedBytes -lt $totalBytes) {
                throw "Download ended early. Expected $totalBytes bytes but received $downloadedBytes bytes."
            }
            if ($totalBytes -le 0) {
                Write-Host ("Download progress: complete ({0})" -f (Format-ByteSize -Bytes $downloadedBytes))
            }
        } finally {
            $outputStream.Dispose()
            $inputStream.Dispose()
        }
    } finally {
        $response.Dispose()
    }
}

function Download-And-InstallPackage {
    param(
        [string]$ZipUrl,
        [string]$ExpectedSha256 = ""
    )
    New-Item -ItemType Directory -Force -Path $DownloadDir | Out-Null
    $tempExtract = Join-Path $DownloadDir ("extract_" + [guid]::NewGuid().ToString("N"))
    $newRoot = Join-Path $DownloadDir ("app_" + [guid]::NewGuid().ToString("N"))
    Remove-Item -LiteralPath $PackageZip -Force -ErrorAction SilentlyContinue
    Write-Host "Downloading latest work programs from GitHub..."
    Write-Host "First install or a version update can take several minutes."
    Write-Host "Install progress: 0% - Downloading package."
    $downloaded = $false
    $lastError = $null
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        try {
            if ($attempt -gt 1) {
                Write-Host "Download attempt $attempt of 3."
            }
            Invoke-DownloadFileWithProgress -Url $ZipUrl -OutFile $PackageZip -TimeoutSec 180
            $downloaded = $true
            break
        } catch {
            $lastError = $_.Exception.Message
            Write-Warning "Download attempt $attempt failed. $lastError"
            Start-Sleep -Seconds ([Math]::Min(10, $attempt * 3))
        }
    }
    if (-not $downloaded) {
        throw "Download failed from $ZipUrl. $lastError"
    }
    Write-Host "Install progress: 75% - Verifying package."
    Test-PackageHash -Path $PackageZip -ExpectedSha256 $ExpectedSha256
    Write-Host "Install progress: 85% - Extracting package."
    New-Item -ItemType Directory -Force -Path $tempExtract | Out-Null
    Expand-Archive -LiteralPath $PackageZip -DestinationPath $tempExtract -Force
    $extractedRoot = Find-ExtractedRoot -ExtractDir $tempExtract
    Write-Host "Install progress: 95% - Installing package."
    New-Item -ItemType Directory -Force -Path $newRoot | Out-Null
    Get-ChildItem -LiteralPath $extractedRoot -Force |
        ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $newRoot -Recurse -Force }
    Stop-RemoteWorkProcesses
    Preserve-BlogAutoUserData
    if (Test-Path -LiteralPath $AppRoot) {
        Remove-PathWithRetry -Path $AppRoot
    }
    Move-Item -LiteralPath $newRoot -Destination $AppRoot -Force
    Remove-Item -LiteralPath $tempExtract -Recurse -Force -ErrorAction SilentlyContinue
    & attrib.exe +h $CacheRoot 2>$null
    Write-Host "Install progress: 100% - Program package is ready."
    Write-Host "Program package is ready."
}

function Ensure-Package {
    Write-Host "Checking latest package version from GitHub..."
    $manifest = Get-RemoteManifest
    $installed = Get-InstalledVersion
    $runner = Join-Path $AppRoot "license_control\launch_with_log.ps1"
    if ([string]::IsNullOrWhiteSpace($installed)) {
        Write-Host "Installed package version: none"
    } else {
        Write-Host "Installed package version: $installed"
    }
    if (-not [string]::IsNullOrWhiteSpace($manifest.Version)) {
        Write-Host "Latest package version: $($manifest.Version)"
    }
    if ((-not (Test-Path -LiteralPath $runner)) -or ($manifest.Version -and $installed -ne $manifest.Version)) {
        Write-Host "A package install or update is required."
        Download-And-InstallPackage -ZipUrl $manifest.ZipUrl -ExpectedSha256 $manifest.Sha256
    } else {
        Write-Host "Installed package is up to date."
    }
}

function Invoke-InstallOnly {
    $installer = Join-Path $AppRoot "license_control\install_all_requirements.ps1"
    if (-not (Test-Path -LiteralPath $installer)) {
        throw "Installer was not found after download: $installer"
    }
    $installerArgs = @("-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $installer)
    if ($DryRun -or $env:REMOTE_WORK_DRY_RUN -eq "1") {
        $installerArgs += @("-DryRun", "-SkipBrowserDownload", "-SkipTesseract")
    }
    & $PowerShellExe @installerArgs
    exit $LASTEXITCODE
}

function Invoke-Router {
    $router = Join-Path $AppRoot "license_control\program_router.ps1"
    $routerExe = Join-Path $AppRoot "license_control\RemoteWorkProgramRouter.exe"
    if ((-not (Test-Path -LiteralPath $routerExe)) -and (-not (Test-Path -LiteralPath $router))) {
        throw "Program router was not found after download: $router"
    }
    if (Test-Path -LiteralPath $routerExe) {
        $routerExeArgs = @()
        if ($DryRun) {
            $routerExeArgs += @("-DryRun", "-SelfTest")
        }
        if ($NoPause) {
            $routerExeArgs += "-NoPause"
        }
        if ($DryRun) {
            & $routerExe @routerExeArgs
            exit $LASTEXITCODE
        }
        Write-Host "Opening Program Router..."
        $startRouterParams = @{
            FilePath = $routerExe
            WorkingDirectory = $AppRoot
            WindowStyle = "Normal"
            PassThru = $true
        }
        if ($routerExeArgs.Count -gt 0) {
            $startRouterParams.ArgumentList = $routerExeArgs
        }
        $routerProcess = Start-Process @startRouterParams
        Start-Sleep -Seconds 1
        if ($routerProcess -and $routerProcess.HasExited) {
            throw "Program Router closed immediately. Try running the launcher again."
        }
        Write-Host "Program Router started. If the login window is behind another window, bring it to the front."
        exit 0
    }
    $routerArgs = @("-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $router)
    if ($DryRun) {
        $routerArgs += @("-DryRun", "-SelfTest")
    }
    if ($NoPause) {
        $routerArgs += "-NoPause"
    }
    if ($DryRun) {
        & $PowerShellExe @routerArgs
        exit $LASTEXITCODE
    }
    Write-Host "Opening Program Router..."
    $routerProcess = Start-Process -FilePath $PowerShellExe -ArgumentList $routerArgs -WorkingDirectory $AppRoot -WindowStyle Hidden -PassThru
    Start-Sleep -Seconds 1
    if ($routerProcess -and $routerProcess.HasExited) {
        throw "Program Router closed immediately. Try running the launcher again."
    }
    Write-Host "Program Router started. If the login window is behind another window, bring it to the front."
    exit 0
}

function Invoke-Program {
    if ([string]::IsNullOrWhiteSpace($ProgramKey)) {
        throw "ProgramKey is required."
    }
    $launcher = Join-Path $AppRoot "license_control\launch_with_log.ps1"
    if (-not (Test-Path -LiteralPath $launcher)) {
        throw "Launcher was not found after download: $launcher"
    }
    $args = @("-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $launcher, "-ProgramKey", $ProgramKey)
    if (-not [string]::IsNullOrWhiteSpace($DisplayName)) {
        $args += @("-DisplayName", $DisplayName)
    }
    if ($DryRun) {
        $args += "-DryRun"
    }
    if ($NoPause) {
        $args += "-NoPause"
    }
    & $PowerShellExe @args
    exit $LASTEXITCODE
}

try {
    Ensure-Package
    if ($InstallOnly) {
        Invoke-InstallOnly
    } elseif ($Router) {
        Invoke-Router
    } else {
        Invoke-Program
    }
} catch {
    Write-Host ""
    Write-Host "Launcher failed." -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-TroubleshootingHelp
    if (-not $NoPause) {
        Read-Host "Press Enter to close"
    }
    exit 1
}
